# Codex Skills

这里保存自己编写、下载、修改或长期使用的 Codex Skills。

建议每个 Skill 单独一个子目录：

```text
codex-skills/
└── skill-name/
    ├── SKILL.md
    ├── README.md
    ├── scripts/
    └── assets/
```

记录时建议补充：

- Skill 来源或原仓库地址
- 主要用途
- 适用场景
- 安装方式
- 修改记录
- 使用注意事项

不建议上传大型模型、缓存、构建产物或临时文件。
